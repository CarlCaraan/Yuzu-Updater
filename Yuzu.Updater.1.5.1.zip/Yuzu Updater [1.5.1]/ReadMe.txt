Yuzu Updater by Sin

Settings have a small summary of what they do so I won't explain them except Sin Mode.

This was needed if you only wanted to download when I updated since I used mediafire and pineapple used anonfiles which is banned in some countries and slow in others.

They have moved onto Github so no longer needed but I'll leave it in anyway :)

If you want help with this or want to join a friendly community then checkout my discord server.

https://discord.gg/nKstg6x

-Sin

