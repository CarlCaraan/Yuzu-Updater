# Yuzu Updater
Totally legal and legit downloader for Yuzu Early Access.
